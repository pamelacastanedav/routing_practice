import React from "react";

const Home = (props) => {
  return (
    <div>
      <h2>Welcome!</h2>
    </div>
  );
};

export default Home;
